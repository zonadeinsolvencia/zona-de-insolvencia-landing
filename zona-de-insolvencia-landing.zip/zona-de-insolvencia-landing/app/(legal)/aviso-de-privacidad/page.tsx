export default function AvisoPrivacidad() {
  return (
    <main className="max-w-3xl mx-auto px-4 py-12 prose prose-slate">
      <h1>Aviso de Privacidad</h1>
      <p>Informamos las finalidades de tratamiento de datos y los derechos de los titulares conforme la normatividad colombiana.</p>
    </main>
  );
}
