export default function PoliticaDatos() {
  return (
    <main className="max-w-3xl mx-auto px-4 py-12 prose prose-slate">
      <h1>Política de Tratamiento de Datos</h1>
      <p>Esta política se rige por la Ley 1581 de 2012 y el Decreto 1377 de 2013 en Colombia.</p>
      <p>Zona de Insolvencia recolecta y trata datos personales con fines de contacto y prestación del servicio jurídico.</p>
      <p>Puedes ejercer tus derechos de acceso, corrección y supresión escribiendo a contacto@zonadeinsolvencia.co.</p>
    </main>
  );
}
