export default function Terminos() {
  return (
    <main className="max-w-3xl mx-auto px-4 py-12 prose prose-slate">
      <h1>Términos del Servicio</h1>
      <p>Condiciones de uso del sitio web y alcance de los servicios legales ofrecidos por Zona de Insolvencia.</p>
    </main>
  );
}
