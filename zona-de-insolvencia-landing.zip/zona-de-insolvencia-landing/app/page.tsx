export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white text-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur bg-white/70 border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-indigo-900 flex items-center justify-center text-white font-bold">ZI</div>
            <div className="leading-tight">
              <p className="font-semibold tracking-tight">Zona de Insolvencia</p>
              <p className="text-xs text-slate-500">Bogotá, Colombia · 320‑349‑0170</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#como-funciona" className="hover:text-indigo-700">Cómo funciona</a>
            <a href="#beneficios" className="hover:text-indigo-700">Beneficios</a>
            <a href="#testimonios" className="hover:text-indigo-700">Testimonios</a>
            <a href="#faq" className="hover:text-indigo-700">FAQ</a>
            <a href="#contacto" className="hover:text-indigo-700">Contacto</a>
          </nav>
          <a
            href="https://wa.me/573203490170?text=Hola%20Zona%20de%20Insolvencia,%20quiero%20asesor%C3%ADa"
            className="inline-flex items-center rounded-2xl px-4 py-2 text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 text-white shadow"
          >
            Hablar por WhatsApp
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative">
        <div className="max-w-6xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight tracking-tight">
              Libérate de tus deudas y recupera tu tranquilidad financiera
            </h1>
            <p className="mt-4 text-lg text-slate-600">
              Somos un despacho legal especializado en insolvencia de persona natural no comerciante,
              conforme al <strong>artículo 531 del Código General del Proceso</strong> y la <strong>Ley 2445 de 2025</strong>.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href="#contacto"
                className="rounded-2xl px-5 py-3 bg-indigo-900 text-white font-semibold shadow hover:shadow-md"
              >
                Agendar asesoría gratis
              </a>
              <a
                href="#como-funciona"
                className="rounded-2xl px-5 py-3 border border-slate-300 text-slate-700 font-semibold hover:border-slate-400"
              >
                Ver cómo funciona
              </a>
            </div>
            <div className="mt-6 flex items-center gap-4 text-sm text-slate-500">
              <div className="flex -space-x-2">
                <div className="h-8 w-8 rounded-full bg-emerald-400/30 border border-white" />
                <div className="h-8 w-8 rounded-full bg-rose-400/30 border border-white" />
                <div className="h-8 w-8 rounded-full bg-indigo-400/30 border border-white" />
              </div>
              <span>+1.000 personas asesoradas</span>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-[4/3] rounded-3xl bg-gradient-to-tr from-indigo-900 via-emerald-400 to-rose-500 p-[2px] shadow-lg">
              <div className="w-full h-full rounded-3xl bg-white p-6 grid">
                <div className="rounded-2xl border border-slate-200 p-5 shadow-sm">
                  <p className="text-sm text-slate-500">Simulador de plan de pagos</p>
                  <h3 className="mt-1 font-semibold">Ejemplo:</h3>
                  <ul className="mt-2 text-sm list-disc pl-5 space-y-1 text-slate-600">
                    <li>Deuda total: $45.000.000</li>
                    <li>Cuota propuesta en negociación: $680.000/mes</li>
                    <li>Plazo estimado: 60 meses</li>
                  </ul>
                  <p className="mt-3 text-xs text-slate-500">*Valores de referencia. El resultado real depende del caso.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Beneficios */}
      <section id="beneficios" className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold">Beneficios de la insolvencia PNNC</h2>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            {[
              {
                t: "Freno a cobros y embargos",
                d: "Medidas para detener llamadas, reportes y procesos mientras negocias con tus acreedores.",
              },
              {
                t: "Una sola cuota alcanzable",
                d: "Un plan de pagos realista, acorde a tus ingresos y gastos básicos.",
              },
              {
                t: "Acompañamiento legal completo",
                d: "Te guiamos en cada etapa ante el centro de conciliación o juzgado.",
              },
            ].map((b, i) => (
              <div key={i} className="rounded-2xl border border-slate-200 p-6 bg-white shadow-sm">
                <h3 className="font-semibold text-lg">{b.t}</h3>
                <p className="mt-2 text-slate-600 text-sm">{b.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Cómo funciona */}
      <section id="como-funciona" className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold">¿Cómo funciona?</h2>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            {[
              {
                n: "1",
                t: "Diagnóstico gratuito",
                d: "Revisamos tus deudas, ingresos y gastos. Identificamos si cumples requisitos del art. 531 CGP.",
              },
              {
                n: "2",
                t: "Negociación de deudas",
                d: "Presentamos la solicitud ante centro de conciliación y proponemos un plan viable.",
              },
              {
                n: "3",
                t: "Plan aprobado o liquidación",
                d: "Si hay acuerdo, cumples tu plan. Si no, solicitamos liquidación patrimonial cuando aplique.",
              },
            ].map((s, i) => (
              <div key={i} className="rounded-2xl border border-slate-200 p-6 bg-white shadow-sm">
                <div className="h-8 w-8 rounded-full bg-indigo-900 text-white flex items-center justify-center font-bold">{s.n}</div>
                <h3 className="mt-3 font-semibold">{s.t}</h3>
                <p className="mt-1 text-sm text-slate-600">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonios */}
      <section id="testimonios" className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold">Lo que dicen nuestros clientes</h2>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            {[
              {
                q: "Dejé de recibir llamadas y pude dormir tranquilo.",
                a: "Cliente de Bogotá",
              },
              {
                q: "La cuota quedó acorde a mi sueldo. Recomendados.",
                a: "Profesional independiente",
              },
              {
                q: "Me explicaron todo con claridad y empatía.",
                a: "Madre cabeza de hogar",
              },
            ].map((t, i) => (
              <figure key={i} className="rounded-2xl border border-slate-200 p-6 bg-white shadow-sm">
                <blockquote className="text-slate-700">“{t.q}”</blockquote>
                <figcaption className="mt-3 text-sm text-slate-500">— {t.a}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold">Preguntas frecuentes</h2>
          <div className="mt-8 grid md:grid-cols-2 gap-6">
            {[
              {
                t: "¿Puedo acogerme si estoy reportado y sin bienes?",
                d: "Sí. La negociación de deudas no exige tener bienes. Si no hay acuerdo y cumples requisitos, puede proceder la liquidación patrimonial.",
              },
              {
                t: "¿Cuánto tarda el proceso?",
                d: "Varía por caso y ciudad. La fase de negociación suele resolverse en meses; la liquidación puede tardar más.",
              },
              {
                t: "¿Pierdo mi salario o mi mínimo vital?",
                d: "No. El plan se diseña respetando tu mínimo vital y cargas familiares.",
              },
              {
                t: "¿Afecta mi vida laboral?",
                d: "No es un proceso penal. Es una herramienta legal para reestructurar deudas y volver a empezar.",
              },
            ].map((f, i) => (
              <div key={i} className="rounded-2xl border border-slate-200 p-6 bg-white shadow-sm">
                <h3 className="font-semibold">{f.t}</h3>
                <p className="mt-2 text-sm text-slate-600">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contacto */}
      <section id="contacto" className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="rounded-3xl border border-slate-200 p-8 bg-white shadow-sm">
            <div className="grid md:grid-cols-2 gap-8 items-start">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold">Agenda tu asesoría gratuita</h2>
                <p className="mt-3 text-slate-600">
                  Cuéntanos tu situación y uno de nuestros abogados se pondrá en contacto contigo.
                </p>
                <ul className="mt-4 text-sm text-slate-600 space-y-1">
                  <li>📍 Atención virtual en toda Colombia</li>
                  <li>📞 WhatsApp: 320‑349‑0170</li>
                  <li>🕘 L‑V 8:00 a.m. – 6:00 p.m.</li>
                </ul>
              </div>
              <form className="grid gap-4" onSubmit={(e)=>e.preventDefault()} aria-label="Formulario de contacto">
                <label className="grid gap-2 text-sm">
                  <span>Nombre completo</span>
                  <input required className="rounded-xl border border-slate-300 px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-400" placeholder="Tu nombre" />
                </label>
                <label className="grid gap-2 text-sm">
                  <span>Correo electrónico</span>
                  <input type="email" required className="rounded-xl border border-slate-300 px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-400" placeholder="tucorreo@email.com" />
                </label>
                <label className="grid gap-2 text-sm">
                  <span>Celular</span>
                  <input required className="rounded-xl border border-slate-300 px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-400" placeholder="300 000 0000" />
                </label>
                <label className="grid gap-2 text-sm">
                  <span>Mensaje</span>
                  <textarea rows={4} className="rounded-xl border border-slate-300 px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-400" placeholder="Cuéntanos brevemente tu caso" />
                </label>
                <div className="flex flex-wrap gap-3">
                  <button className="rounded-2xl px-5 py-3 bg-emerald-500 text-white font-semibold shadow hover:bg-emerald-600" type="submit">Enviar</button>
                  <a className="rounded-2xl px-5 py-3 border border-slate-300 font-semibold hover:border-slate-400" href="mailto:contacto@zonadeinsolvencia.co?subject=Asesoría">Escribir por correo</a>
                  <a className="rounded-2xl px-5 py-3 border border-slate-300 font-semibold hover:border-slate-400" href="tel:+573203490170">Llamar</a>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Al enviar tus datos aceptas nuestra Política de Tratamiento de Datos y uso de cookies.
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-4 gap-8 text-sm">
          <div>
            <p className="font-semibold">Zona de Insolvencia</p>
            <p className="mt-2 text-slate-600">Insolvencia persona natural no comerciante.</p>
          </div>
          <div>
            <p className="font-semibold">Enlaces</p>
            <ul className="mt-2 space-y-1 text-slate-600">
              <li><a href="#beneficios" className="hover:text-indigo-700">Beneficios</a></li>
              <li><a href="#como-funciona" className="hover:text-indigo-700">Proceso</a></li>
              <li><a href="#faq" className="hover:text-indigo-700">Preguntas</a></li>
              <li><a href="#contacto" className="hover:text-indigo-700">Contacto</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold">Legal</p>
            <ul className="mt-2 space-y-1 text-slate-600">
              <li><a href="/politica-de-datos" className="hover:text-indigo-700">Política de datos (Ley 1581/2012)</a></li>
              <li><a href="/aviso-de-privacidad" className="hover:text-indigo-700">Aviso de privacidad</a></li>
              <li><a href="/terminos" className="hover:text-indigo-700">Términos del servicio</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold">Contáctanos</p>
            <p className="mt-2 text-slate-600">WhatsApp 320‑349‑0170</p>
            <a
              href="https://wa.me/573203490170?text=Hola%20Zona%20de%20Insolvencia,%20quiero%20asesor%C3%ADa"
              className="inline-flex mt-3 items-center rounded-2xl px-4 py-2 text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 text-white shadow"
            >
              Escribir por WhatsApp
            </a>
          </div>
        </div>
        <p className="text-center text-xs text-slate-400 mt-8">© {new Date().getFullYear()} Zona de Insolvencia. Todos los derechos reservados.</p>

        {/* JSON-LD Schema.org */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'LegalService',
              name: 'Zona de Insolvencia',
              areaServed: 'CO',
              address: { addressLocality: 'Bogotá', addressCountry: 'CO' },
              telephone: '+57-320-349-0170',
              url: 'https://zonadeinsolvencia.co',
              sameAs: [
                'https://www.instagram.com/zonadeinsolvencia/'
              ],
              serviceType: 'Insolvencia persona natural no comerciante',
            }),
          }}
        />
      </footer>
    </div>
  );
}
