import "./../styles/globals.css";
import type { Metadata } from "next";
import Analytics from "@/components/analytics";

export const metadata: Metadata = {
  title: "Zona de Insolvencia — Libérate de tus deudas",
  description: "Insolvencia de persona natural no comerciante en Colombia. Asesoría gratuita por abogados expertos.",
  metadataBase: new URL("https://example.com"),
  openGraph: {
    title: "Zona de Insolvencia — Libérate de tus deudas",
    description: "Asesoría jurídica para insolvencia PNNC (art. 531 CGP y Ley 2445 de 2025).",
    type: "website",
  },
  icons: { icon: "/favicon.ico" }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  );
}
