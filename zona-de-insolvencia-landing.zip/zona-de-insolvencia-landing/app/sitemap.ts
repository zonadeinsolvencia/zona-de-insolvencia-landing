import type { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: 'https://example.com/', changeFrequency: 'weekly', priority: 1 },
    { url: 'https://example.com/politica-de-datos', changeFrequency: 'yearly', priority: 0.5 },
    { url: 'https://example.com/aviso-de-privacidad', changeFrequency: 'yearly', priority: 0.5 },
    { url: 'https://example.com/terminos', changeFrequency: 'yearly', priority: 0.5 },
  ]
}
